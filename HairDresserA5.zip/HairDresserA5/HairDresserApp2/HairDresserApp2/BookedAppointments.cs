﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HairDresserApp2
{
    [XmlRoot("HairDresser")]
    public class BookedAppointments : IEnumerable<Appointment>
    {
        
        private List<Appointment> bookedAppointmentsList;

        [XmlArray("AppointmentList")]
        [XmlArrayItem("Appointment")]
        public List<Appointment> BookedAppointmentsList { get => bookedAppointmentsList; set => bookedAppointmentsList = value; }


        public BookedAppointments()
        {
            bookedAppointmentsList = new List<Appointment>();
        }

        public void Add(Appointment appointment)
        {
            bookedAppointmentsList.Add(appointment);
        }

        // Sorting the List<Appointment>
        public void Sort()
        {
            this.bookedAppointmentsList.Sort();
        }

        public IEnumerator<Appointment> GetEnumerator()
        {
            return ((IEnumerable<Appointment>)bookedAppointmentsList).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<Appointment>)bookedAppointmentsList).GetEnumerator();
        }

        public int Count
        {
            get { return bookedAppointmentsList.Count; }
        }

        
        public Appointment this[int i]
        {
            get { return bookedAppointmentsList[i]; }
            set { bookedAppointmentsList[i] = value; }
        }
    }
}
