﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp2
{
    enum SalonOptions
    {
        bookAppointment = 1, appointmentList = 2, exit = 3
    }

    public class Program
    {
        //Dictionary for Time Slots
        SortedDictionary<int, string> availableSlots = new SortedDictionary<int, string>();

        // Class that holds the list of appointments(Indexer)
        BookedAppointments bookedAppointments = new BookedAppointments();

        static void Main(string[] args)
        {
            Program program = new Program();
            program.Go();
            Console.ReadKey();
        }


        private void Go()
        {
            string userAppointementInputString = string.Empty;
            int userChoice;
            Console.WriteLine("********* Welcome to HairDressing Salon *********\n");
            try
            {
                //Method to populate Available Slots
                buildAvailableSlots();
                do
                {
                    do
                    {
                        Console.WriteLine("=> Here are the options we provide");
                        Console.WriteLine("1) Book an Appointment");
                        Console.WriteLine("2) View Appointments");
                        Console.WriteLine("3) Exit and View Summary");
                        Console.Write("Choose an option(1-3): ");
                        userAppointementInputString = Console.ReadLine();
                    } while (!int.TryParse(userAppointementInputString, out userChoice) || (userChoice < 1) || (userChoice > 3));

                    //Main Menu option
                    switch (userChoice)
                    {
                        case (int)SalonOptions.bookAppointment:
                            bookAppointment();
                            break;
                        case (int)SalonOptions.appointmentList:
                            viewAppointments();
                            break;
                        case (int)SalonOptions.exit:
                            appointmentsExecution();
                            Console.WriteLine("You have now exited the Salon Booking System.Have a good day :) ");
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (userChoice != 3);
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }
        }

        //Funtion for Booking Appointment
        private void bookAppointment()
        {
            int selectedSlot;
            String readSlot = string.Empty;

            //Display Available Slots
            Console.WriteLine("Available Slots");
            foreach (var slot in availableSlots)
            {
                Console.WriteLine(" {0}. {1}", slot.Key, slot.Value);
            }

            //Prompt for Slot Selection
            do
            {
                Console.Write("Select your prefered slot(1-8): ");
                readSlot = Console.ReadLine();
            } while (!int.TryParse(readSlot, out selectedSlot) || !availableSlots.ContainsKey(selectedSlot));


            string name = string.Empty; ;
            do
            {
                //Prompt for User Name
                Console.Write("Enter your Name: ");
                name = Console.ReadLine();
            } while ((name.Length == 0) || (name.Length > 50));


            string readAge = string.Empty;
            uint age;
            do
            {
                //Prompt for User Age
                Console.Write("Enter your Age (1-100): ");
                readAge = Console.ReadLine();
            } while (!uint.TryParse(readAge, out age) || (age < 1) || (age > 100));


            string readHeight = string.Empty;
            decimal height;
            do
            {
                //Prompt for User Height
                Console.Write("Enter your Height (1-10 ft): ");
                readHeight = Console.ReadLine();
            } while (!decimal.TryParse(readHeight, out height) || (height < 1) || (height > 10));


            string readCreditCard = string.Empty;
            long CreditCardNumber;
            do
            {
                //Prompt for Credit Card
                Console.Write("Enter your 16 Degit Credit Card Number: ");
                readCreditCard = Console.ReadLine();
            } while (!long.TryParse(readCreditCard, out CreditCardNumber) || (readCreditCard.Length != 16));



            string readGender = string.Empty;
            do
            {
                //Prompt for Gender
                Console.Write("Enter your Gender (M/F): ");
                readGender = Console.ReadLine();
            } while (!(readGender.ToUpper() == "M" || readGender.ToUpper() == "F"));

            Appointment appointment = new Appointment();

            //Conditions for Client Categorization (Children [Male/Female], Ladies, Gentlemen)
            if (age <= 18)
            {
                appointment.Customer = new Children(name, age, height, readCreditCard, readGender.ToUpper());
                appointment.Category = Category.Children;
                ((Children)appointment.Customer).IsChild = true;
              
            }
            else
            {
                if (readGender.ToUpper().Equals("F"))
                {
                    appointment.Customer = new Ladies(name, age, height, readCreditCard, readGender.ToUpper());
                    appointment.Category = Category.Ladies;
                    ((Ladies)appointment.Customer).IsLady = true;
                }
                else
                {
                    appointment.Customer = new Gentlemen(name, age, height, readCreditCard, readGender.ToUpper());
                    appointment.Category = Category.Gentlemen;
                    ((Gentlemen)appointment.Customer).IsGentleman = true;
                }
            }

            //Store Appointment TimeStamp
            if (availableSlots.ContainsKey(selectedSlot))
            {
                appointment.TimeStamp = availableSlots[selectedSlot];
            }

            //Populating Booked Slots
            bookedAppointments.Add(appointment);

            Console.WriteLine("\n# Appointment BOOKED at {0}. Available Services: Common & {1} Services\n", appointment.TimeStamp, appointment.Category);

            //removes the selected slot from the available slots
            availableSlots.Remove(selectedSlot);
        }

        //Function to View Appointment list
        private void viewAppointments()
        {
            Console.WriteLine("------ Appointment List ------ Sort By: Age");
            //Sorting the List<Appointment> by Age
            bookedAppointments.Sort();
            foreach (var item in bookedAppointments)
            {
                Appointment appointment = item;
                Customer client = (Customer)appointment.Customer;
                Console.WriteLine($"Time: {appointment.TimeStamp}, CustomerDetails - Name: {client.CustomerName}, Age: {client.CustomerAge} Category: {appointment.Category}, Payment - credit card: {client.CustomerCreditCardNumber}");
            }
            Console.WriteLine(" ");
        }

        //Method to build Available Slots
        public void buildAvailableSlots()
        {
            availableSlots.Add(1, "09:00 A.M");
            availableSlots.Add(2, "10:00 A.M");
            availableSlots.Add(3, "11:00 A.M");
            availableSlots.Add(4, "12:00 P.M");
            availableSlots.Add(5, "02:00 P.M");
            availableSlots.Add(6, "03:00 P.M");
            availableSlots.Add(7, "04:00 P.M");
            availableSlots.Add(8, "05:00 P.M");
        }

        //Function To Perform Operations 
        public void appointmentsExecution()
        {
            // Sorting the list by Age
            bookedAppointments.Sort();
            Console.WriteLine($"Total Appointments : {bookedAppointments.Count()}");
            foreach (var item in bookedAppointments)
            {
                Appointment appointment = item;
                Customer client = (Customer)appointment.Customer;
               
                // Category String for Display 
                string categoryStr = (appointment.Category == Category.Children) ? (client.CustomerGender.Equals("M") ? "Male Child" : "Female Child"): (client.CustomerGender.Equals("M") ? "Gentleman" : "Ladies");
                
                Console.WriteLine($"Appointment at {appointment.TimeStamp}, CustomerDetails - Name:{client.CustomerName} Age:{client.CustomerAge}" +
                                  $" Height:{client.CustomerHeight} Category:{categoryStr}, credit card: {client.CustomerCreditCardNumber}");

                Console.WriteLine("Services performed");
                //Executing Operations according to Client Category
                switch (appointment.Category)
                {
                    case Category.Children:
                        Children Child = (Children)client;
                        Child.PerformOperations();
                        break;
                    case Category.Ladies:
                        Ladies lady = (Ladies)client;
                        lady.PerformOperations();
                        break;
                    case Category.Gentlemen:
                        Gentlemen men = (Gentlemen)client;
                        men.PerformOperations();
                        break;
                    default:
                        Console.WriteLine("None");
                        break;
                }
                // Calling delegate to execute the required Tasks
                client.DoServices();  
            }
        }

    }
}
