﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HairDresserApp2
{
    
    public enum Category
    {
        Children, Ladies, Gentlemen,
    }
    public class Appointment : IAppointment
    {
        private string timeStamp;
        [XmlEnum]
        private Category category;
        private Customer customer;
        private string availedServices;

        public Appointment() { }
        public Appointment(string timeStamp, Category category, Customer customer, string availedServices)
        {
            this.timeStamp = timeStamp;
            this.category = category;
            this.customer = customer;
            this.availedServices = availedServices;
        }

        public string TimeStamp { get => timeStamp; set => timeStamp = value; }
        public Customer Customer { get => customer; set => customer = value; }
        public Category Category { get => category; set => category = value; }
        public string AvailedServices { get => availedServices; set => availedServices = value; }


        // Comparing the age of customer
        public int CompareTo(Appointment other)
        {
            return this.customer.CustomerAge.CompareTo(other.customer.CustomerAge);
        }
    }
}
