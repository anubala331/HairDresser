﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using HairDresserApp2;
using System.Xml.Serialization;
using System.Collections.ObjectModel;

namespace HairDresserA5
{
    class Operations
    {
        string filePath;

        public Operations()
        {
            filePath = "Appointments.xml";
        }

        // Function to write into XML File
        public void WriteToXML(AppointmentList appointments)
        {
            TextWriter writer = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(AppointmentList));
                writer = new StreamWriter(filePath);
                serializer.Serialize(writer, appointments);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }


        // Function to Read Data from XML File
        public AppointmentList ReadFromXML()
        {
            AppointmentList allAppointment = new AppointmentList();
            StreamReader reader = null;
            if (File.Exists(filePath))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(AppointmentList));
                    reader = new StreamReader(filePath);
                    allAppointment = (AppointmentList)serializer.Deserialize(reader);
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
            }
            else
            {
                Console.WriteLine("File Does Not Exists");
            }

            return allAppointment;
        }


        // Function To build Appointment Object 
        public Appointment GetAppointmentObj(string timeSlot, string name, uint age, decimal height, string creditCard, string gender, string services)
        {
            Appointment appointment = new Appointment();

            appointment.TimeStamp = timeSlot;
            appointment.AvailedServices = services;

            //Conditions for Client Categorization (Children [Male/Female], Ladies, Gentlemen)
            if (age <= 18)
            {
                appointment.Customer = new Children(name, age, height, creditCard, gender);
                appointment.Category = Category.Children;
                ((Children)appointment.Customer).IsChild = true;

            }
            else
            {
                if (gender.Equals("Female"))
                {
                    appointment.Customer = new Ladies(name, age, height, creditCard, gender);
                    appointment.Category = Category.Ladies;
                    ((Ladies)appointment.Customer).IsLady = true;
                }
                else
                {
                    appointment.Customer = new Gentlemen(name, age, height, creditCard, gender);
                    appointment.Category = Category.Gentlemen;
                    ((Gentlemen)appointment.Customer).IsGentleman = true;
                }
            }

            return appointment;

        }

    }

}