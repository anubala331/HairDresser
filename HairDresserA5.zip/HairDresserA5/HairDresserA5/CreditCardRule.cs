﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Controls;

namespace HairDresserA5
{
    class CreditCardRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            long card;
            if (!long.TryParse(value.ToString(), out card))
            {
                return new ValidationResult(false, "Numeric Value only");
                
            }
            if (value.ToString().Length != 16)
            {
                return new ValidationResult(false, "Should be 16 Digit");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
            
        }
    }
}
