﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace HairDresserA5
{
    class HeightInRangeRule : ValidationRule
    {
        decimal min;
        decimal max;

        public decimal Min { get => min; set => min = value; }
        public decimal Max { get => max; set => max = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            
            decimal number;
            if (!decimal.TryParse((string)value, out number))
            {
                return new ValidationResult(false,
                    "Invalid Data Type");
            }
            if (number < min || number > max)
            {
                return new ValidationResult(false,
                    $"Out of range ({Min}-{Max})");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }
}
