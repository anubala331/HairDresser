﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace HairDresserA5
{
    class AgeInRangeRule :ValidationRule
    {
        int min;
        int max;

        public int Min { get => min; set => min = value; }
        public int Max { get => max; set => max = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {

            int number;
            if (!int.TryParse((string)value, out number))
            {
                return new ValidationResult(false,
                    "Invalid Data Type");
            }
            if (number < min || number > max)
            {
                return new ValidationResult(false,
                    $"Out of range ({Min}-{Max})");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }
}
