﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using HairDresserApp2;


namespace HairDresserA5
{
  
    public partial class MainWindow : Window
    {
        Operations operations = new Operations();
        uint readAge;
        decimal readHeight;
        string creditCardNumber;
        string gender = string.Empty;
        string inputName;

        List<string> availableSlots = new List<string>();

        AppointmentList appointmentList;

        AppointmentList filterAppointmentList = new AppointmentList();
        public AppointmentList AppointmentList { get => appointmentList; set => appointmentList = value; }
        public uint ReadAge { get => readAge; set => readAge = value; }
        public decimal ReadHeight { get => readHeight; set => readHeight = value; }
        public string CreditCardNumber { get => creditCardNumber; set => creditCardNumber = value; }
        public string InputName { get => inputName; set => inputName = value; }

        public MainWindow()
        {
            InitializeComponent();

            appointmentList = new AppointmentList();
            
            builtTimeSlots(operations.ReadFromXML()); //populating timeslot combobox 

            DataContext = this;

        }

        //Error Handler and will add the error message to tooltip
        protected void errorHandler(object sender, ValidationErrorEventArgs e)
        {
            TextBox errorField = (TextBox)sender;
            errorField.ToolTip = (string)e.Error.ErrorContent;
        }
     

        private void bookAppointment_Click(object sender, RoutedEventArgs e)
        {
            //validate input fields
            bool flag = validateData();
            
            // Check for empty data and if window has any invalid Rule
            if (flag && !Validation.GetHasError(nameInput) && !Validation.GetHasError(ageInput) && !Validation.GetHasError(heightInput) && !Validation.GetHasError(creditCardInput))
            {
                // Services according to categories
                string services = buildServices();
               
                //Building Appointment Object
                Appointment appointment = operations.GetAppointmentObj(timeSlotMenu.Text, nameInput.Text, readAge, readHeight, creditCardInput.Text, gender, services);
                
                // Adding appointment to an obserable collection
                appointmentList.Add(appointment);

                // removal of chosen timeslot from the Combobox;
                availableSlots.Remove(timeSlotMenu.Text);
                timeSlotMenu.Items.Refresh();
              
                
                // If Combobox is empty Disable the Book Appointment Button
                if (timeSlotMenu.Items.Count <= 0)
                {
                    bookAppointment.IsEnabled = false;
                    bookAppointment.ToolTip = "Appointments Full";
                }
                resetForm();
            }

        }

        // Event handler for View Appointment Button
        private void ViewAppointment_Click(object sender, RoutedEventArgs e)
        {
            appointmentList.Clear();
            appointmentList = operations.ReadFromXML();
            if (appointmentList != null && appointmentList.Count > 0)
            {
                appointmentList.Sort();//Sorting list by Age (LINQ)
                tableGrid.ItemsSource = appointmentList.BookedAppointmentsList;
                infoText.Content = string.Empty;
            }
            else
            {
                infoText.Content = "No Data Found";
            }  
        }

        // Event handler for Save Button Clicked
        private void SaveData_Click(object sender, RoutedEventArgs e)
        {
            if (appointmentList.Count > 0)// If List has any Data
            {
                operations.WriteToXML(appointmentList);
                infoText.Content = "Data Saved - Click View to load Data";
                appointmentList.Clear(); // Removing Data from the grid once SAVED to File(Xml) 
            }
        }


        // Function for Search by Customer Name
        private void Search_Click(object sender, RoutedEventArgs e)
        {
            filterAppointmentList.Clear();
            string searchValue = searchInput.Text;
            var query = from appointment in appointmentList.BookedAppointmentsList
                        where appointment.Customer.CustomerName.ToLower().Equals(searchValue.ToLower())
                        select appointment;
            foreach (Appointment appointment in query)
            {
                filterAppointmentList.BookedAppointmentsList.Add(appointment);
            }
            tableGrid.ItemsSource = filterAppointmentList.BookedAppointmentsList;
        }

        // Function to check search input length, if zero then
        // it will change the Datagrid source back to unfiltered List
        private void CheckLength(object sender, TextChangedEventArgs e)
        {
            if (searchInput.Text == null || searchInput.Text.Length == 0)
            {
                filterAppointmentList.Clear();
                tableGrid.ItemsSource = appointmentList.BookedAppointmentsList;
            }
        }

        // Handler for Radio Buttons change event
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            switch (rb.Name)
            {
                case "male":
                    gender = "Male";
                    break;
                case "female":
                    gender = "Female";
                    break;
                default:
                    break;
            }
            // Dynamic Handling (enable/disable) Checkboxs according to age and gender selection
            handledCheckBoxes();
        }


        // Function To validate inputs before adding to list/File
        private bool validateData()
        {
            bool flag = true;
            if ((inputName == null) || (inputName.Length < 0) || (readAge == 0) || (readHeight==0m) || (creditCardNumber == null))
            {
                infoText.Content = "Please Fill All Valid Data";
                flag = false;
            }
            if ((commonCheckBox.IsChecked == false) && (gentlemenCheckBox.IsChecked == false) && (ladiesCheckBox.IsChecked == false) && (ChildrenCheckBox.IsChecked == false))
            {
                infoText.Content = "Select Atleast One Service";
                flag = false;
            }
            return flag;
        }

        // Dynamic Handling (enable/disable) Checkboxs according to age and gender selection
        private void handledCheckBoxes()
        {
            if (ageInput.Text.Length > 0)
            {
                uint age = 0;

                if (uint.TryParse(ageInput.Text, out age) && (age <= 100))
                {
                    if (age <= 18)
                    {
                        if (gender.Equals("Female"))
                        {
                            ladiesCheckBox.IsEnabled = true;
                            gentlemenCheckBox.IsEnabled = false;
                            gentlemenCheckBox.IsChecked = false;
                        }
                        else
                        {
                            gentlemenCheckBox.IsEnabled = true;
                            ladiesCheckBox.IsEnabled = false;
                            ladiesCheckBox.IsChecked = false;
                        }
                        ChildrenCheckBox.IsEnabled = true;
                    }
                    else
                    {
                        if (gender.Equals("Female"))
                        {
                            ladiesCheckBox.IsEnabled = true;
                            gentlemenCheckBox.IsEnabled = false;
                            gentlemenCheckBox.IsChecked = false;

                        }
                        else
                        {
                            gentlemenCheckBox.IsEnabled = true;
                            ladiesCheckBox.IsEnabled = false;
                            ladiesCheckBox.IsChecked = false;

                        }
                        ChildrenCheckBox.IsEnabled = false;
                        ChildrenCheckBox.IsChecked = false;

                    }
                }
            }

        }

        // Handling checkboxes on "OnkeyUp" event of ageInput
        private void ageOnKeyUp(object sender, KeyEventArgs e)
        {
            handledCheckBoxes();
        }

        public void builtTimeSlots(AppointmentList fileList)
        {
            availableSlots.Add("09:00 AM");
            availableSlots.Add("10:00 AM");
            availableSlots.Add("11:00 AM");
            availableSlots.Add("12:00 PM");
            availableSlots.Add("02:00 PM");
            availableSlots.Add("03:00 PM");
            availableSlots.Add("04:00 PM");
            availableSlots.Add("05:00 PM");
            if (fileList != null)
            {
                foreach (Appointment app in fileList.BookedAppointmentsList)
                {
                    if (availableSlots.Contains(app.TimeStamp))
                    {
                        availableSlots.Remove(app.TimeStamp);
                    }
                }
            }
            timeSlotMenu.ItemsSource = availableSlots;
            if (timeSlotMenu.Items.Count <= 0)
            {
                bookAppointment.IsEnabled = false;
                bookAppointment.ToolTip = "NO Slot Available";
            }
        }

        // Fuction for form default state
        private void resetForm()
        {
            timeSlotMenu.SelectedIndex = 0;
            InputName = string.Empty;
            ReadAge = 0;
            ReadHeight = 0m;
            // clearing All fields
            CreditCardNumber = string.Empty;
            nameInput.Text = string.Empty;
            ageInput.Text = string.Empty;
            heightInput.Text = string.Empty;
            creditCardInput.Text = string.Empty;
            searchInput.Text = string.Empty;
            male.IsChecked = true;
            female.IsChecked = false;
            commonCheckBox.IsChecked = true;
            ChildrenCheckBox.IsEnabled = false;
            ladiesCheckBox.IsEnabled = false;
            gentlemenCheckBox.IsEnabled = false;
            ChildrenCheckBox.IsChecked = false;
            ladiesCheckBox.IsChecked = false;
            gentlemenCheckBox.IsChecked = false;
            infoText.Content = string.Empty;
        }

        // Services according to categories
        private string buildServices()
        {
            StringBuilder availedServices = new StringBuilder();

            if ((bool)commonCheckBox.IsChecked)
            {
                availedServices.Append("Hair - Trim, Dye, Wash! ");
            }
            if ((bool)ladiesCheckBox.IsChecked && (bool)ChildrenCheckBox.IsChecked)
            {
                availedServices.Append("Styling for Occasions with sensitive trimmer & adjustable seat! ");
            }
            if ((bool)gentlemenCheckBox.IsChecked && (bool)ChildrenCheckBox.IsChecked)
            {
                availedServices.Append("Trim Beard & Moustache with sensitive trimmer & adjustable seat! ");
            }
            if ((bool)ladiesCheckBox.IsChecked && !(bool)ChildrenCheckBox.IsChecked)
            {
                availedServices.Append("Styling for Occasions! ");
            }
            if ((bool)gentlemenCheckBox.IsChecked && !(bool)ChildrenCheckBox.IsChecked)
            {
                availedServices.Append("Trim Beard & Trim moustache! ");
            }
            if ((bool)ChildrenCheckBox.IsChecked && !(bool)ladiesCheckBox.IsChecked && !(bool)gentlemenCheckBox.IsChecked)
            {
                availedServices.Append("Sensitive trimmer & adjustable seat! ");
            }

            return availedServices.ToString();
        }
        
    }
}
