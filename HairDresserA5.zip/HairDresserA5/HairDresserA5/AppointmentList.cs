﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using HairDresserApp2;

namespace HairDresserA5
{
    [XmlRoot("HairDresser")]
    public class AppointmentList
    {
        
        private ObservableCollection<Appointment> bookedAppointmentsList;

        [XmlArray("AppointmentList")]
        [XmlArrayItem("Appointment")]
        public ObservableCollection<Appointment> BookedAppointmentsList { get => bookedAppointmentsList; set => bookedAppointmentsList = value; }

        public AppointmentList()
        {
            bookedAppointmentsList = new ObservableCollection<Appointment>();
        }


        public void Add(Appointment appointment)
        {
            bookedAppointmentsList.Add(appointment);
        }

        public void Remove(Appointment appointment)
        {
            bookedAppointmentsList.Remove(appointment);
        }

        
        public void Sort() // Sorting list using LINQ
        {
            var orderedList = from appointment in BookedAppointmentsList
                        orderby appointment.Customer.CustomerAge
                        select appointment;
            BookedAppointmentsList = new ObservableCollection<Appointment>();
            foreach (Appointment appointment in orderedList)
            {
                BookedAppointmentsList.Add(appointment);
            }
        }

        public int Count
        {
            get { return bookedAppointmentsList.Count; }
        }

        public void Clear()
        {
            bookedAppointmentsList.Clear();
        }

        public Appointment this[int i]
        {
            get { return bookedAppointmentsList[i]; }
            set { bookedAppointmentsList[i] = value; }
        }
    }
}
